﻿using System;
using System.Collections.Generic;

namespace ConsoleApp1
{
    public class flask
    {
        public int f_Num;
        public char color1;
        public char color2;
        public char color3;
        public char color4;
    }
    public class color_Set
    {
        public int tot_colors;
        public int start_A = int.Parse("A");
        public List<Char> col_list;
        public void make_set(List<Char> list, int tot_num)
        {
            for (int i = 0; i < tot_num; i++) 
            {
                int stNum = start_A + i;
                list.Add(Convert.ToChar(stNum));
            }

        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            

        }
    }
}
